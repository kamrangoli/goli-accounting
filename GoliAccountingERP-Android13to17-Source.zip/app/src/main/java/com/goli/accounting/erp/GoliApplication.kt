package com.goli.accounting.erp

import android.app.Application

class GoliApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // راه‌اندازی اولیه پایگاه داده آفلاین Room
    }
}
