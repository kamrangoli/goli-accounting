package com.goli.accounting.core.database.entity

import androidx.room.*

@Entity(tableName = "chart_of_accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val level: String, // group, general, subsidiary, detailed
    val parentId: String? = null,
    val accountType: String, // asset, liability, equity, revenue, expense
    val balance: Long = 0L,
    val isFloating: Boolean = false
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val barcode: String,
    val sku: String,
    val name: String,
    val category: String,
    val mainUnit: String,
    val subUnit: String?,
    val subUnitMultiplier: Int = 1,
    val costPrice: Long,
    val retailPrice: Long,
    val wholesalePrice: Long,
    val bulkPrice: Long,
    val minStockAlert: Int = 20,
    val taxPercent: Int = 10
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val voucherNumber: Long,
    val jalaliDate: String,
    val description: String,
    val totalDebit: Long,
    val totalCredit: Long,
    val isBalanced: Boolean = true,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val phone: String,
    val nationalId: String?,
    val creditLimit: Long,
    val currentBalance: Long,
    val isLocked: Boolean = false
)
