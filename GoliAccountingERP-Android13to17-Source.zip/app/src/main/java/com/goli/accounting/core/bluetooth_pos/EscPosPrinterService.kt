package com.goli.accounting.core.bluetooth_pos

import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

class EscPosPrinterService {
    companion object {
        val ESC_INIT = byteArrayOf(0x1B, 0x40)
        val ESC_ALIGN_CENTER = byteArrayOf(0x1B, 0x61, 0x01)
        val ESC_ALIGN_RIGHT = byteArrayOf(0x1B, 0x61, 0x02)
        val ESC_BOLD_ON = byteArrayOf(0x1B, 0x45, 0x01)
        val ESC_BOLD_OFF = byteArrayOf(0x1B, 0x45, 0x00)
        val ESC_FEED_AND_CUT = byteArrayOf(0x1D, 0x56, 0x41, 0x10)
    }

    suspend fun printReceipt(
        socket: BluetoothSocket,
        invoiceNum: String,
        customerName: String,
        totalToman: Long
    ) = withContext(Dispatchers.IO) {
        val out: OutputStream = socket.outputStream
        out.write(ESC_INIT)
        out.write(ESC_ALIGN_CENTER)
        out.write(ESC_BOLD_ON)
        out.write("فروشگاه بازرگانی گلی\n".toByteArray(charset("Windows-1256")))
        out.write("رسید رسمی صندوق مکانیزه POS\n\n".toByteArray(charset("Windows-1256")))
        out.write(ESC_BOLD_OFF)
        out.write(ESC_ALIGN_RIGHT)
        out.write("شماره فاکتور: $invoiceNum\n".toByteArray(charset("Windows-1256")))
        out.write("مشتری: $customerName\n".toByteArray(charset("Windows-1256")))
        out.write("مبلغ کل: $totalToman تومان\n".toByteArray(charset("Windows-1256")))
        out.write(ESC_FEED_AND_CUT)
        out.flush()
    }
}
