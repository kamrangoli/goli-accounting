package com.goli.accounting.core.hardware_pda

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PdaBarcodeScannerReceiver(
    private val onBarcodeScanned: (String) -> Unit
) : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return
        val honeywellCode = intent.getStringExtra("data")
        val zebraCode = intent.getStringExtra("com.symbol.datawedge.data_string")
        val code = honeywellCode ?: zebraCode
        if (!code.isNullOrBlank()) {
            onBarcodeScanned(code.trim())
        }
    }
}
