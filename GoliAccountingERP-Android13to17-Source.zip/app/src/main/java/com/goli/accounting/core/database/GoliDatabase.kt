package com.goli.accounting.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.goli.accounting.core.database.dao.AccountingDao
import com.goli.accounting.core.database.entity.*

@Database(
    entities = [
        AccountEntity::class,
        ProductEntity::class,
        JournalEntryEntity::class,
        CustomerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GoliDatabase : RoomDatabase() {
    abstract fun accountingDao(): AccountingDao

    companion object {
        @Volatile
        private var INSTANCE: GoliDatabase? = null

        fun getDatabase(context: Context): GoliDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GoliDatabase::class.java,
                    "goli_accounting.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
